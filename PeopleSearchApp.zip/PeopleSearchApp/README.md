# PeopleSearchApp
a basic react app with .NET Core web api
